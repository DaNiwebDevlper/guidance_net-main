import React from 'react'

const ServiceDetail = () => {
    return (
        <div>ServiceDetail</div>
    )
}

export default ServiceDetail